#include <iostream>
#include <vector>
#include <string>
#include <sstream>

int main() {
    using namespace std;
    vector<pair<int, int>> ranges;

    int minFound = 0;
    int maxFound = 0;
    string line;
    while (getline(cin, line) && line != ".") {
        stringstream lineStream(line);

        int min;
        int max;
        lineStream >> min;
        lineStream >> max;

        if (min < minFound)
            minFound = min;

        if (max > maxFound)
            maxFound = max;

        ranges.push_back(pair<int, int>(min, max));
    }

    while (cin >> line && line != ".") {
        int number = stoi(line);


        bool isInRange = false;

        if (number < minFound) {
            cout << "out" << endl;
            continue;
        } else if (number > maxFound) {
            cout << "out" << endl;
            continue;
        } else {
            for (const auto &item : ranges) {
                if (number >= item.first && number <= item.second) {
                    isInRange = true;
                    break;
                }
            }
        }


        if (isInRange) {
            cout << "in" << endl;
        } else {
            cout << "out" << endl;
        }
    }

    return 0;
}
