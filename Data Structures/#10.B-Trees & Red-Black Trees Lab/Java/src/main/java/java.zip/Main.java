public class Main {

    public static void main(String[] args) {

        RedBlackTree<Integer> rbt = new RedBlackTree<>();
        rbt.insert(0);
        rbt.insert(1);
        rbt.insert(2);
        rbt.insert(3);
        rbt.insert(4);
        rbt.insert(5);
        rbt.insert(6);
        rbt.insert(7);
        rbt.insert(8);
        rbt.insert(9);

        //left-a da proverq
        System.out.println();
    }
}
