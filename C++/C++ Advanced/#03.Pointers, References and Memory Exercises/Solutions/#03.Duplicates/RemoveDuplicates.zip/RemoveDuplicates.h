#include <list>
#include "Company.h"
#include "algorithm"

bool containsCompanyByName(std::list<Company *> companies, std::string name) {
    for (const Company *company : companies) {
        if (company->getName() == name) {
            return true;
        }
    }
    return false;
}

void removeDuplicates(std::list<Company *> &companies) {

    std::list<Company *> result;

    for (auto i = companies.begin(); i != companies.end(); i++) {
        Company *company = *i;

        if (!containsCompanyByName(result, company->getName())) {
            result.push_back(company);
        }
    }

    companies = result;
}

