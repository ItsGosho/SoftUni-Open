#include<iostream>
using namespace std;

int main() {
    char letter = 'a';
    char sameLetter = 97;
    char sameLetterAgain = 'b' - 1;

    cout << letter << sameLetter << sameLetterAgain << endl;

    return 0;
}
