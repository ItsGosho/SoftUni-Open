#include "string"
#include "vector"
#include "Company.h"

using namespace std;

using sPtr = std::shared_ptr<Company>;

sPtr makeCompany(const std::vector<std::string>& properties) {
    int id = stoi(properties[0]);
    string name = properties[1];

    vector<pair<char, char>> employees;

    for (int i = 2; i < properties.size(); ++i) {
        string property = properties[i];
        employees.push_back(pair<char, char>(property[0], property[1]));
    }

    shared_ptr<Company> company(new Company(id, name, employees));

    return company;
}