public class Main {

    public static void main(String[] args) {

        Integer[] arr = new Integer[]{5,2,0,-4,3,12};
        Heap.sort(arr);
        System.out.println();
    }
}
