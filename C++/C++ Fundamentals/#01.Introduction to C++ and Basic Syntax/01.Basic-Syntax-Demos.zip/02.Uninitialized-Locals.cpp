#include<iostream>

int main() {
    int georgeApples;
    std::cout << georgeApples << std::endl;
    return 0;
}
