#ifndef ECHO_H
#define ECHO_H

#include <iostream>

extern bool echoOn;

void echo(const std::string& val);

#endif //ECHO_H
