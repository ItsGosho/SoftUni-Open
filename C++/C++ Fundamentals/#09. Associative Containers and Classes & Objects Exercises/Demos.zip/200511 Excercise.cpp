// Sli.do: cpp-fundamentals

extern void Problem1(void);
extern void Problem2(void);
extern void Problem3(void);
extern void Problem4(void);

int main()
{
	Problem4();
}
