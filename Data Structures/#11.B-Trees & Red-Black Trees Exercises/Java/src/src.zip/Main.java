public class Main {
    public static void main(String[] args) {

//        Hierarchy<Integer> hierarchy = new Hierarchy<>(1);
//
//        hierarchy.add(1,10);
//        hierarchy.add(1,15);
//        hierarchy.add(1,20);
//        hierarchy.add(20,40);
//        hierarchy.add(10,13);
//
//        hierarchy.getChildren(3123);
    }
}
