﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class ArrayList<T>
{
    private const int InitialCapacity = 2;

    private int capacity;
    private int count;
    private T[] elements;

    public ArrayList()
    {
        this.capacity = InitialCapacity;
        this.elements = new T[this.capacity];
    }

    public ArrayList(int capacity)
    {
        this.capacity = capacity;
        this.elements = new T[this.capacity];
    }

    public int Count()
    {
        return this.count;
    }

    public void Add(T item)
    {

        if (this.count == this.capacity)
        {
            this.Grow();
        }

        this.elements[count] = item;
        this.count++;

    }

    public T this[int index]
    {
        get
        {
            if (index > this.count - 1)
            {
                throw new IndexOutOfRangeException();
            }

            return this.elements[index];
        }
    }

    public void RemoveAt(int index)
    {
        if (index > this.count)
        {
            return;
        }

        T[] newArray = new T[this.count - 1];

        for (int i = 0; i < index; i++)
        {
            newArray[i] = this.elements[i];
        }

        for (int i = index; i < this.count; i++)
        {
            if (i + 1 > this.count)
            {
                newArray[i] = this.elements[i + 1];
            }
        }

        this.elements = newArray;
        this.count--;

    }

    private void Grow()
    {
        T[] newArray = new T[this.capacity * 2];

        this.copyIntoNewArray(newArray);

        this.elements = newArray;
        this.capacity = this.capacity * 2;
    }

    private void copyIntoNewArray(T[] arrayToBeFilled)
    {

        for (int i = 0; i < this.count; i++)
        {
            T currentElement = this.elements[i];

            if (currentElement != null)
            {
                arrayToBeFilled[i] = currentElement;
            }
        }

    }

}
