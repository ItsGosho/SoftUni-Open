public class Main {

    public static void main(String[] args) {
        HashTable<String, String> hashTable = new HashTable<>();


        double result = (Double.parseDouble("1") / Double.parseDouble("2")) * 100;
        System.out.println();

        hashTable.add("Jorko", "2");
        hashTable.add("Mariika", "5");
        hashTable.add("Ivancho", "6");
        hashTable.add("AaAa", "4");
        hashTable.add("BBBB", "9");

        System.out.println();
    }
}
