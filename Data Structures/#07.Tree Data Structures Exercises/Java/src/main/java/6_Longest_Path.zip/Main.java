import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {

        Tree<Integer> tree = createTreeFromInput();

        List<Integer> deepestNodesPath = new ArrayList<>();

        Stack<Tree<Integer>> result = tree.getLongestPath();

        while (result.size() != 0){
            deepestNodesPath.add(result.pop().getValue());
        }

        System.out.println("Longest path: "+ deepestNodesPath.stream().map(Object::toString).collect(Collectors.joining(" ")));
    }

    private static Tree<Integer> createTreeFromInput() {
        Tree<Integer> tree = new Tree<>();
        Scanner scanner = new Scanner(System.in);
        int operationsCount = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < operationsCount - 1; i++) {
            String[] input = scanner.nextLine().split("\\s+");
            int father = Integer.parseInt(input[0]);
            int value = Integer.parseInt(input[1]);

            tree.attachChildren(father, value);
        }

        return tree;
    }

}
