public class Heap {

    public static <E> void sort(E[] array) {
        throw new UnsupportedOperationException();
    }
}
