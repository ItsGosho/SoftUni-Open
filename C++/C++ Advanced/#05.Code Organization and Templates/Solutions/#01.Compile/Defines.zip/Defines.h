#define DONT_COMPILE_THIS

#include <string>
#include <iostream>

#define STANDARD_TEMPLATE_LIBRARY namespace std;