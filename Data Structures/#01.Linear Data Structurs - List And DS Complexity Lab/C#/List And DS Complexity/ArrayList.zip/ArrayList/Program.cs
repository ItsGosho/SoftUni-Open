﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {

        ArrayList<int> test = new ArrayList<int>();
        test.Add(1);


        test.RemoveAt(0);

        Console.WriteLine();
    }
}
