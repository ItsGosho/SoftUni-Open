#include <string>

bool tryParse(std::string a, int& b);